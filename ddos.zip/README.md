![logo](yoshc.jpg)
<img align="left" src="https://user-images.githubusercontent.com/65187002/144930161-2f783401-8d27-4fdf-a2f7-cc0ba32f1f1f.gif" width="21%" style="display:inline;"><img align="right" src="https://user-images.githubusercontent.com/65187002/144930161-2f783401-8d27-4fdf-a2f7-cc0ba32f1f1f.gif" width="21%" style="display:inline;">

<h1 align="center">Hi 👋, I'm YoshCassaster</h1>
<h3 align="center">A passionate Programmer from INDONESIA</h3>
<p align="center">Source Code Gabut | Niatnya saya buat untuk menganggu nasabah di pekerjaan saya saat itu🛠️</p>
<p align="center"> 
 <img src="https://komarev.com/ghpvc/?username=supuna97&label=Profile%20views&color=0e75b6&style=flat" alt="supun nanayakkara" /> 
<!--  <img src="https://img.shields.io/badge/Languages-Python | Java | PHP | Typescript | Node | React -green.svg" alt="supun nanayakkara's languages" /> -->
<!--  <img alt="Profile followers" src="https://img.shields.io/github/followers/supuna97"> -->
</p>

<div align="center">
  <img src="https://techstack-generator.vercel.app/java-icon.svg" alt="icon" width="50" height="50" />
  <img src="https://techstack-generator.vercel.app/python-icon.svg" alt="icon" width="50" height="50" />
  <img src="https://techstack-generator.vercel.app/js-icon.svg" alt="icon"width="50" height="50" />
</div>

<br>

<div align="center">
  <img src="https://techstack-generator.vercel.app/docker-icon.svg" alt="icon" width="50" height="50" />
  <img src="https://techstack-generator.vercel.app/aws-icon.svg" alt="icon" width="50" height="50" />
  <img src="https://techstack-generator.vercel.app/github-icon.svg" alt="icon" width="50" height="50" />
  <img src="https://techstack-generator.vercel.app/prettier-icon.svg" alt="icon" width="50" height="50" />
  <img src="https://techstack-generator.vercel.app/restapi-icon.svg" alt="icon" width="50" height="50" />
  <img src="https://techstack-generator.vercel.app/graphql-icon.svg" alt="icon" width="50" height="50" />
</div>

<img align="right" alt="Coding" width="400" src="https://user-images.githubusercontent.com/74038190/229223263-cf2e4b07-2615-4f87-9c38-e37600f8381a.gif">
<br><br>

- ✅ SUPPORT ALL BUTTON (ANDROID)

- 🔐SC INI DILINDUNGI OLEH CREATOR🔒

- 🔭 BUG WHATSAPP PRIVATE CHAT 

- 🌱 BUG WHATSAPP GROUP 

- 👨‍💻 BOOM BUG WHATSAPP 

- ⚡ Fun fact **I think I'm funny**

- 🔴 BASE SC | XEON

<br>
<h3 align="left">Connect with me:</h3>
<p align="left">
<a href="https://linkedin.com/in/yosepwahyudanuarto" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="supunnanayakkara" height="30" width="40" /></a>
<a href="https://stackoverflow.com/users/9565088/yosepwahyudanuarta" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/stack-overflow.svg" alt="supun-nanayakkara" height="30" width="40" /></a>
<a href="https://instagram.com/yosepwdd" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="supun___lk" height="30" width="40" /></a>
</p>
<br>

<img src="https://i.imgur.com/dBaSKWF.gif" height="20" width="100%">

<h3 align="left">INTERFACE BOT WHATSAPP | IOS</h3>

- MENU
<p align="left">
  <a href="https://google.com">
    <img src="./menu.jpg" />
  </a>
</p>

- ALLMENU MENU
<p align="left">
  <a href="https://google.com">
    <img src="./allmenu.jpg" />
  </a>
</p>

- BUG MENU
<p align="left">
  <a href="https://google.com">
    <img src="./bugmenu.jpg" />
  </a>
</p>

</p>

<br/>

<img src="https://i.imgur.com/dBaSKWF.gif" height="20" width="100%">

<h3 align="left">Trophy:</h3>

<p align="center">
<img src="https://media.tenor.com/0ENB5HuTH0gAAAAi/trophy-beker.gif"  width="100px" height="100px"></p>
  
<div align="center">
<img src="https://github-profile-trophy.vercel.app/?username=supuna97&theme=matrix&no-bg=true&no-frame=true&row=1&column=4&title=MultiLanguage,Commits,PullRequest,Reviews">
 </div>

<div align="center">
<img src="https://github-profile-trophy.vercel.app/?username=supuna97&theme=matrix&no-bg=true&no-frame=true&row=1&column=4&title=Repositories,Organizations,Stars,Followers">
 </div>
 <br><br>

<img src="https://i.imgur.com/dBaSKWF.gif" height="20" width="100%">

<h3 align="left">GitHub Stats:</h3>
<div align="center">
 
![YoshCasaster GitHub stats](https://github-readme-stats.vercel.app/api?username=YoshCasaster\&theme=midnight-purple\&show_icons=true\&show=reviews,prs_merged,prs_merged_percentage\&hide=contribs,issues)

[![GitHub Streak](https://streak-stats.demolab.com/?user=supuna97&theme=midnight-purple)](https://git.io/streak-stats)

</div>

<br><br>

<img src="https://i.imgur.com/dBaSKWF.gif" height="20" width="100%">

<h3 align="left">Activity:</h3>

![YoshCasaster Graph](https://github-readme-activity-graph.vercel.app/graph?username=YoshCasastercustom_title=Supun's%20GitHub%20Activity%20Graph&bg_color=0D1117&color=7F3FBF&line=7F3FBF&point=7F3FBF&area_color=FFFFFF&title_color=FFFFFF&area=true)
<br><br>

<img src="https://i.imgur.com/dBaSKWF.gif" height="20" width="100%">


<img src="https://media.giphy.com/media/LnQjpWaON8nhr21vNW/giphy.gif" width="60"> <em><b>I love connecting with different people</b> so if you want to say <b>hi, I'll be happy to meet you more!</b> :)</em>

<br>
<p align="right" > Created with 🧡 by <a href="#"></>TeamCassaster</></a></p>
